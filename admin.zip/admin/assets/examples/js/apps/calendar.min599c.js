/*!
 * Remark (http://getbootstrapadmin.com/remark)
 * Copyright 2017 amazingsurge
 * Licensed under the Themeforest Standard Licenses
 */

!function(global,factory){if("function"==typeof define&&define.amd)define("/apps/calendar",["jquery"],factory);else if("undefined"!=typeof exports)factory(require("jquery"));else{var mod={exports:{}};factory(global.jQuery),global.appsCalendar=mod.exports}}(this,function(_jquery){"use strict";(0,babelHelpers.interopRequireDefault(_jquery).default)(document).ready(function(){AppCalendar.run()})});