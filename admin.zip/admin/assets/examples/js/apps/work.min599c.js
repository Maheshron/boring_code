/*!
 * Remark (http://getbootstrapadmin.com/remark)
 * Copyright 2017 amazingsurge
 * Licensed under the Themeforest Standard Licenses
 */

!function(global,factory){if("function"==typeof define&&define.amd)define("/apps/work",[],factory);else if("undefined"!=typeof exports)factory();else{var mod={exports:{}};factory(),global.appsWork=mod.exports}}(this,function(){"use strict";$(document).ready(function(){AppWork.run()})});