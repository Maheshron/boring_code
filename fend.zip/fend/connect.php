<?php

$con = mysqli_connect('localhost','edelweissuser','edelweissuser1','edelweiss');

?>